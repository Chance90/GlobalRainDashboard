#!/usr/bin/env python
# coding: utf-8

# In[1]:


from bson.objectid import ObjectId
from pymongo import MongoClient


class MongCRUD:
    def __init__(self):
        USER = 'aacuser'
        PASS = 'chance'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31847
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):

            result = self.collection.insert_one(data)
            if result.inserted_id:
                print("Data added\n")

            else:
                print("Failed\n")

    def read(self, query):

        try:
            result = self.collection.find(query)
            return result
        except Exception as e:
            print(e)
        return None
    
    def update(self, query, data):
        
            result = self.collection.update_many(query, {"$set": data})
            if result.modified_count > 0:
                print("Data Updated\n")
                
            else:
                print("Failed\n")

    def delete(self, query):
        
            result = self.collection.delete_many(query)
            if result.deleted_count > 0:
                print("Data deleted\n")
            else:
                print("Data not deleted\n")


# In[ ]:




